'use strict'

const loginContainer = document.getElementById('login-container')

const moveOverlay = () => loginContainer.classList.toggle('move')

document.getElementById('open-register').addEventListener('click', moveOverlay)
document.getElementById('open-login').addEventListener('click', moveOverlay)

document.getElementById('open-register-mobile').addEventListener('click', moveOverlay)
document.getElementById('open-login-mobile').addEventListener('click', moveOverlay)

async function logar() {
    const email = document.getElementById("input_email_login").value;
    const password = document.getElementById("input_password_login").value;

    try {
        const user = await axios.post("http://localhost:4000/api/users/login", {
            email,
            password
        });

        console.log(user.status)

        if (user.status === 200) {
            localStorage.setItem("token", user.data.data)

            window.location = "/";
        }
    } catch (error) {
        const invalidCredentialsError = error.response.status === 400 && error.response.data.message === "Invalid Credentials"

        if (invalidCredentialsError) {
        var emailInput = document.getElementById("input_email_login");
        var passwordInput = document.getElementById("input_password_login");


            document.getElementById("login_error").innerHTML = "Erro ao logar!"
            emailInput.style.border = "3px solid red"
            passwordInput.style.border = "3px solid red"
        }
    }



}